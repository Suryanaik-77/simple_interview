"""
cogni.adapters.weather.json.oracle
=========================
Generic JSON-file-backed reality. The toy scenario uses this: a hand-
authored ground-truth file plays the role of "what really happened."

The oracle is dumb on purpose. It answers: "given a situation_id, hand
back the recorded measurements." That is enough for the agent to be
verdict-able.
"""
from __future__ import annotations
import json
import os
from agent.core import Reality, new_id


class JsonOracle:
    def __init__(self, ground_truth_path: str, source_label: str = "ground_truth.json"):
        self.path = ground_truth_path
        self.source_label = source_label
        if not os.path.exists(ground_truth_path):
            raise FileNotFoundError(ground_truth_path)
        with open(ground_truth_path) as f:
            self.data = json.load(f)

    def reality_for(self, situation_id: str) -> Reality:
        sit = self.data.get("situations", {}).get(situation_id)
        if not sit:
            raise KeyError(f"unknown situation: {situation_id}")
        return Reality(
            id=new_id("real"),
            source=f"{self.source_label}#{situation_id}",
            measurements=sit.get("measurements", {}),
            artifacts=[self.path],
        )
