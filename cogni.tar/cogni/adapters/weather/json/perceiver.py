"""
cogni.adapters.weather.json.perceiver
====================
Toy non-VLSI perceiver. Reads a JSON file of weather observations and
emits Facts + tags. Demonstrates that the cognitive framework is
domain-agnostic: same Perceiver, different adapter, different KB.

Input format (one situation per perceive call):

    {
      "location": "San Jose, CA",
      "time_of_day": "1800 PT",
      "temp_c": 14.0,
      "dewpoint_c": 13.0,
      "humidity_pct": 92,
      "wind_kmh": 4,
      "pressure_hpa": 1012,
      "pressure_change_6h_hpa": -1.5,
      "sky": "clear",
      "near_coast": true,
      "onshore_flow": false,
      "inversion": false,
      "cape_jkg": 200,
      "trigger": null,
      "ridge_5h": false
    }
"""
from __future__ import annotations
import json
import os
from agent.core import WorldModel


class WeatherObsAdapter:
    domain = "weather"

    def perceive(self, world: WorldModel, raw_input: str) -> None:
        if not os.path.exists(raw_input):
            world.add("perception.error", f"missing obs file {raw_input}",
                      source="adapter:weather_obs", tags=["perception_error"])
            return
        with open(raw_input) as f:
            obs = json.load(f)

        world.add("loc", obs.get("location", "unknown"),
                  source=raw_input, tags=["weather_obs"])
        world.add("time_of_day", obs.get("time_of_day", ""),
                  source=raw_input, tags=[])

        temp = obs.get("temp_c"); dew = obs.get("dewpoint_c")
        if temp is not None:
            world.add("temp_c", temp, source=raw_input, tags=[])
        if dew is not None:
            world.add("dewpoint_c", dew, source=raw_input, tags=[])
        if temp is not None and dew is not None and (temp - dew) <= 3.0:
            world.add("dewpoint_gap", temp - dew, source=raw_input,
                      tags=["temp_near_dewpoint"])

        hum = obs.get("humidity_pct")
        if hum is not None:
            world.add("humidity_pct", hum, source=raw_input,
                      tags=["humidity_high"] if hum >= 85 else [])

        wind = obs.get("wind_kmh")
        if wind is not None:
            world.add("wind_kmh", wind, source=raw_input,
                      tags=["calm_wind"] if wind <= 8 else (["windy"] if wind >= 25 else []))

        pchg = obs.get("pressure_change_6h_hpa")
        if pchg is not None:
            world.add("pressure_change_6h_hpa", pchg, source=raw_input,
                      tags=["pressure_falling_fast"] if pchg <= -4 else [])

        sky = obs.get("sky")
        if sky:
            world.add("sky", sky, source=raw_input,
                      tags=["clear_sky"] if sky.lower().startswith("clear") else [])

        if obs.get("near_coast"):
            world.add("near_coast", True, source=raw_input, tags=["coastal"])
        if obs.get("onshore_flow"):
            world.add("onshore_flow", True, source=raw_input, tags=["onshore_flow"])
        if obs.get("inversion"):
            world.add("inversion", True, source=raw_input, tags=["inversion_present"])

        cape = obs.get("cape_jkg")
        if cape is not None:
            world.add("cape_jkg", cape, source=raw_input,
                      tags=["high_cape"] if cape >= 1500 else [])
        if obs.get("trigger"):
            world.add("trigger", obs["trigger"], source=raw_input, tags=["trigger_present"])

        if obs.get("ridge_5h"):
            world.add("ridge_5h", True, source=raw_input, tags=["strong_high_pressure"])
